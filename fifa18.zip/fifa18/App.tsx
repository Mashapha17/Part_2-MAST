import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TextInput, Button, FlatList, TouchableOpacity, } from 'react-native';
import { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native'; 
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Picker } from '@react-native-picker/picker';

const Stack = createNativeStackNavigator();

export default function App() { 
  return (
    <NavigationContainer> 
      <Stack.Navigator>
        <Stack.Screen name="Home" component={MainScreen} />
        <Stack.Screen name="SecondPage" component={SecondPage} />
      </Stack.Navigator>      
    </NavigationContainer> 
  );
}

// Define the type for navigation prop
type MainScreenProps = {
  navigation: {
    navigate: (screen: string, params?: object) => void;
  };
};

// Meal type
type Meal = {
  id: number;
  name: string;
  price: number;
  type: string; // 'Main Course', 'Dessert', or 'Starters'
};

// MainScreen component
function MainScreen({ navigation }: MainScreenProps) { 
  const [meals, setMeals] = useState<Meal[]>([]);
  const [mealName, setMealName] = useState<string>(''); 
  const [mealPrice, setMealPrice] = useState<string>(''); 
  const [mealType, setMealType] = useState<string>('Main Course'); // Default to 'Main Course'

  // Function to add a meal
  const addMeal = () => {
    if (mealName && mealPrice && mealType) {
      const newMeal: Meal = {
        id: meals.length + 1,
        name: mealName,
        price: parseFloat(mealPrice),
        type: mealType,
      };
      setMeals([...meals, newMeal]);
      setMealName('');
      setMealPrice('');
      setMealType('Main Course'); // Reset type to default
    }
  };

  // Function to remove a meal by its id
  const removeMeal = (id: number) => {
    setMeals(meals.filter(meal => meal.id !== id));
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput 
        placeholder="Meal Name" 
        onChangeText={newText => setMealName(newText)} 
        value={mealName}
        style={styles.input} 
      />
      <TextInput 
        placeholder="Meal Price" 
        onChangeText={newText => setMealPrice(newText)} 
        value={mealPrice}
        keyboardType="numeric"
        style={styles.input} 
      />

      <Picker
        selectedValue={mealType}
        style={styles.picker}
        onValueChange={(itemValue) => setMealType(itemValue)}
      >
        <Picker.Item label="Main Course" value="Main Course" />
        <Picker.Item label="Dessert" value="Dessert" />
        <Picker.Item label="Starters" value="Starters" />
      </Picker>

      <Button title="Add Meal" onPress={addMeal} />

      <Text>Total Meals: {meals.length}</Text> {/* Display the total number of meals */}

      <FlatList 
        data={meals}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.mealItem}>
            <Text>{item.name} ({item.type}): R{item.price.toFixed(2)}</Text>
            <TouchableOpacity onPress={() => removeMeal(item.id)}>
              <Text style={styles.removeButton}>Remove</Text>
            </TouchableOpacity>
          </View>
        )}
      />

      <Button 
        title="Next Page"
        onPress={() => navigation.navigate('SecondPage', { meals })}
      />
    </View>
  );
}

// SecondPage component
function SecondPage({ route } :any ) {
  const { meals } = route.params;
  const [selectedMeals, setSelectedMeals] = useState<number[]>([]);

  // Calculate the total whenever selected meals change
  const totalCost = selectedMeals.reduce((total, mealId) => {
    const selectedMeal = meals.find((meal: Meal) => meal.id === mealId);
    return total + (selectedMeal ? selectedMeal.price : 0);
  }, 0);

  // Handle selecting/deselecting a meal
  const toggleMealSelection = (id: number) => {
    setSelectedMeals(prevSelected =>
      prevSelected.includes(id)
        ? prevSelected.filter(mealId => mealId !== id) // Remove if already selected
        : [...prevSelected, id] // Add if not selected
    );
  };

  return (
    <View style={{ padding: 20 }}>
      <Text>Select your meals:</Text>

      <FlatList 
        data={meals}
        keyExtractor={(item: Meal) => item.id.toString()}
        renderItem={({ item }: { item: Meal }) => (
          <TouchableOpacity onPress={() => toggleMealSelection(item.id)}>
            <Text style={{ backgroundColor: selectedMeals.includes(item.id) ? 'lightgreen' : 'white' }}>
              {item.name}: R{item.price.toFixed(2)}
            </Text>
          </TouchableOpacity>
        )}
      />

      <Text>Total Cost: R{totalCost.toFixed(2)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  picker: {
    height: 50,
    width: '100%',
    marginBottom: 12,
  },
  mealItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  removeButton: {
    color: 'red',
    marginLeft: 10,
  },
});